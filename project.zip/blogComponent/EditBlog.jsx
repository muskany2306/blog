import React ,{useEffect,useState} from 'react';
import { useParams,useNavigate } from 'react-router-dom';

const EditBlog = () =>{
    const {id}=useParams();
    const [post,setPost]=useState(null);
    const navigate=useNavigate();


    useEffect(()=>{
        const fetchPost =async()=>{
            const response =await fetch(`http://localhost:3000/posts/${id}`);
            const data =await response.json();
            setPost(data);
        };
        fetchPost();
    },[id]);

    const handleSubmit=async(e)=>{
        e.preventDefault();
        await fetch(`http://localhost:3000/posts/${id}`,{
            method:'PUT',
            headers:{'content-type':'application/json'},
            body:JSON.stringify(post),
                
            
        });
        navigate('/');
    };

    if(!post) return null;

    return(
        <form onSubmit={handleSubmit}>
         <input value={post.title} onChange={(e)=>setPost({...post, title: e.target.value})}/>
         <textarea value={post.content} onChange={(e)=>setPost({...post, content: e.target.value})}/>
            <button type="submit">Update blog</button>
        </form>
    );
};

export default EditBlog