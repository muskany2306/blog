import React from 'react';
import {Route,Routes} from 'react-router-dom';
import Home from './blogComponent/Home';
import CreateBlog from './blogComponent/CreateBlog';
import BlogDetails from './blogComponent/BlogDetails';
import EditBlog from './blogComponent/EditBlog';
import Navbar from './blogComponent/Navbar';

function App() {
  return (
    <div>
    
      
      <Navbar/>
      <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/blog/:id/create" element={<CreateBlog/>}/>
      <Route path="/edit/:id" element={<EditBlog/>}/>
      </Routes>
    </div>
  )
}

export default App
