import React ,{useState} from 'react';
import { useNavigate } from 'react-router-dom';

const CreateBlog=()=>{
    const [title,setTitle]=useState('');
    const [content,setContent]=useState('');
    const navigate = useNavigate();

    const handleSubmit=async(e)=>{
       e.preventDefault();
       const newPost = {title,content ,author:'Author Name',createdAt:new Date()};
       await fetch('http://localhost:3001/posts',{
        method:'POST',
        headers:{'content-type':'application/json'},
        body:JSON.stringify(newPost),
       });
       navigate('/');
    };

    return(
        <form onSumbit={handleSubmit}>
            <input required value={title} onChange={(e)=>setTitle(e.target.value)}/>
            <textarea required value={content}onChange={(e)=>setContent (e.target.value)}/>
                <button type='submit'>Create Blog</button>
        </form>
    );
};

export default CreateBlog;