import React , { useEffect , useState} from 'react';
import {Link} from 'react-router-dom';


const Home=()=>{
    const [posts,setPosts]= useState([]);

    useEffect(()=>{
        const fetchPosts = async()=>{
            const response =await fetch('http://localhost:3001/posts');
            const data = await response.json();
             setPosts(data);
        };
        fetchPosts();
    },[]);

    const deletePost =async(id)=>{
        await fetch(`http://localhost:3001/posts/${id}`,{
            method:'DELETE',
        });

        setPosts(posts.filter(post=>post.id!==id));
    };

    return (
        <div>
            <h1>Blog Posts</h1>
            {posts.map(post=>(
                <div key={post.id}>
                    <h2>{post.title}</h2>
                    <p>{post.content.substring(0,100)}...</p>
                    <Link to={`/edit/${post.id}`}>Edit</Link>
                    <button onClick={()=>deletePost(post.id)}Delete></button>
                </div>    
            ))}
        </div>
    );
};

export default Home