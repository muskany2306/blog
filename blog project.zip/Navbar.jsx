import React from 'react';
import {Link} from 'react-router-dom';

const Navbar=()=>(
    <nav>
        <Link to="/">Home</Link>
        <Link to="/blog/new">Create Blog</Link>
    </nav>
);
export default Navbar;